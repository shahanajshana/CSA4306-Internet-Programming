
const defaultRooms = [
    { name: "Standard Room", price: 1500, qty: 10,
      desc: "Comfortable room with basic amenities" },
    { name: "Deluxe Room", price: 2500, qty: 8,
      desc: "Spacious room with premium facilities" },
    { name: "Suite Room", price: 4000, qty: 5,
      desc: "Luxury room with a separate living area" },
    { name: "Family Room", price: 3500, qty: 6,
      desc: "Large room suitable for families" }
];

let rooms = JSON.parse(localStorage.getItem("rooms")) || defaultRooms;
let users = JSON.parse(localStorage.getItem("users")) || [];
let bookings = JSON.parse(localStorage.getItem("bookings")) || [];
let currentUser = localStorage.getItem("currentUser") || "";
let selected = 0;
let isAdmin = false;

const $ = id => document.getElementById(id);

function save() {
    localStorage.setItem("rooms", JSON.stringify(rooms));
    localStorage.setItem("users", JSON.stringify(users));
    localStorage.setItem("bookings", JSON.stringify(bookings));
}

function showPanel(id) {
    document.querySelectorAll(".panel").forEach(p => p.style.display = "none");
    $(id).style.display = "block";
    $(id).scrollIntoView({ behavior: "smooth" });
}

function hidePanels() {
    document.querySelectorAll(".panel").forEach(p => p.style.display = "none");
}

function showLogin() {
    showPanel("account");
    $("formTitle").textContent = "Login";
}

function showRegister() {
    showPanel("account");
    $("formTitle").textContent = "Register";
}

function register() {
    let name = $("name").value.trim();
    let email = $("email").value.trim().toLowerCase();
    let password = $("password").value;

    if (!name || !email || password.length < 6) {
        alert("Enter your name, email and password (at least 6 characters).");
        return;
    }

    if (users.some(u => u.email === email)) {
        alert("This email is already registered.");
        return;
    }

    users.push({
        name, email, password,
        phone: $("phone").value,
        bookings: []
    });

    save();
    alert("Registration successful. Please login.");
}

function login() {
    let email = $("email").value.trim().toLowerCase();
    let password = $("password").value;
    let user = users.find(u => u.email === email && u.password === password);

    if (!user) {
        alert("Invalid email or password.");
        return;
    }

    currentUser = email;
    localStorage.setItem("currentUser", currentUser);
    alert("Welcome, " + user.name + "!");
    hidePanels();
}

function logout() {
    currentUser = "";
    isAdmin = false;
    localStorage.removeItem("currentUser");
    alert("Logged out.");
    hidePanels();
}

function updateProfile() {
    let user = users.find(u => u.email === currentUser);

    if (!user) {
        alert("Please login first.");
        return;
    }

    let name = $("name").value.trim();
    let phone = $("phone").value.trim();

    if (name) user.name = name;
    if (phone) user.phone = phone;

    save();
    alert("Profile updated.");
}

function available(index, start, end, excludeId = null) {
    let occupied = bookings.filter(b =>
        b.room === index &&
        b.status === "Confirmed" &&
        b.id !== excludeId &&
        start < b.checkOut &&
        end > b.checkIn
    ).length;

    return occupied < rooms[index].qty;
}

function renderRooms() {
    $("roomList").innerHTML = rooms.map((r, i) => `
        <div class="room">
            <h3>${r.name}</h3>
            <p>${r.desc}</p>
            <p class="price">₹${r.price} / night</p>
            <p>Rooms available in inventory: ${r.qty}</p>
            <button onclick="bookRoom(${i})">Book Now</button>
        </div>
    `).join("");
}

function searchRooms() {
    let start = $("checkin").value;
    let end = $("checkout").value;
    let guests = Number($("guests").value);

    if (!start || !end || end <= start || guests < 1) {
        alert("Enter valid dates and guest count.");
        return;
    }

    let destination = $("destination").value.trim();
    $("message").textContent = "Search results for " +
        (destination || "all destinations") + ":";

    $("roomList").innerHTML = rooms.map((r, i) => {
        let free = available(i, start, end);
        return `
            <div class="room">
                <h3>${r.name}</h3>
                <p>${r.desc}</p>
                <p class="price">₹${r.price} / night</p>
                <p>${free ? "Available" : "Not available"} for these dates</p>
                <button ${free ? "" : "disabled"}
                    onclick="bookRoom(${i})">Book Now</button>
            </div>
        `;
    }).join("");

    selected = 0;
}

function bookRoom(index) {
    if (!currentUser) {
        alert("Please register and login before booking.");
        showLogin();
        return;
    }

    selected = index;
    $("selectedRoom").textContent =
        rooms[index].name + " — ₹" + rooms[index].price + " per night";

    $("bookIn").value = $("checkin").value;
    $("bookOut").value = $("checkout").value;
    $("bookGuests").value = $("guests").value || 1;

    showPanel("bookingForm");
}

function confirmBooking() {
    if (!currentUser) {
        alert("Please login first.");
        return;
    }

    let start = $("bookIn").value;
    let end = $("bookOut").value;
    let guests = Number($("bookGuests").value);

    if (!start || !end || end <= start || guests < 1) {
        alert("Enter valid dates and guest count.");
        return;
    }

    if (start < new Date().toISOString().slice(0, 10)) {
        alert("Check-in cannot be in the past.");
        return;
    }

    if (!available(selected, start, end)) {
        alert("No rooms available for these dates.");
        return;
    }

    let nights = Math.round(
        (new Date(end) - new Date(start)) / 86400000
    );

    let total = nights * rooms[selected].price;

    let booking = {
        id: Date.now(),
        email: currentUser,
        room: selected,
        checkIn: start,
        checkOut: end,
        guests,
        total,
        status: "Confirmed"
    };

    if (!confirm("Total: ₹" + total +
        "\nDemo payment only. Confirm this booking?")) return;

    bookings.push(booking);
    save();

    alert("Booking confirmed! Booking ID: " + booking.id +
        "\nPayment is simulated; no real payment was collected.");

    hidePanels();
    showBookings();
}

function canChange(b) {
    let arrival = new Date(b.checkIn + "T00:00:00");
    let today = new Date();
    today.setHours(0, 0, 0, 0);

    return (arrival - today) / 86400000 >= 3;
}

function showBookings() {
    if (!currentUser) {
        alert("Please login first.");
        showLogin();
        return;
    }

    showPanel("history");

    let mine = bookings.filter(b => b.email === currentUser);

    $("bookingList").innerHTML = mine.length ? mine.map(b => `
        <div class="room">
            <p><b>Booking ID:</b> ${b.id}</p>
            <p><b>Room:</b> ${rooms[b.room]?.name || "Room"}</p>
            <p>${b.checkIn} to ${b.checkOut}</p>
            <p>Guests: ${b.guests}</p>
            <p>Total: ₹${b.total}</p>
            <p>Status: ${b.status}</p>
            ${b.status === "Confirmed" && canChange(b) ? `
                <button onclick="changeBooking(${b.id})">Change Dates</button>
                <button onclick="cancelBooking(${b.id})">Cancel Booking</button>
            ` : ""}
            <button onclick="leaveReview(${b.id})">Review</button>
        </div>
    `).join("") : "<p>No bookings found.</p>";
}

function changeBooking(id) {
    let b = bookings.find(x => x.id === id && x.email === currentUser);

    if (!b || b.status !== "Confirmed" || !canChange(b)) {
        alert("Changes are allowed only at least 3 days before arrival.");
        return;
    }

    let start = prompt("Enter new check-in date (YYYY-MM-DD):", b.checkIn);
    if (!start) return;

    let end = prompt("Enter new check-out date (YYYY-MM-DD):", b.checkOut);
    if (!end) return;

    if (start < new Date().toISOString().slice(0, 10) || end <= start) {
        alert("Invalid dates.");
        return;
    }

    if (!available(b.room, start, end, b.id)) {
        alert("Room unavailable for the selected dates.");
        return;
    }

    let nights = Math.round((new Date(end) - new Date(start)) / 86400000);

    b.checkIn = start;
    b.checkOut = end;
    b.total = nights * rooms[b.room].price;

    save();
    alert("Booking dates updated.");
    showBookings();
}

function cancelBooking(id) {
    let b = bookings.find(x => x.id === id && x.email === currentUser);

    if (!b || b.status !== "Confirmed" || !canChange(b)) {
        alert("Cancellation is allowed only at least 3 days before arrival.");
        return;
    }

    if (confirm("Cancel this booking?")) {
        b.status = "Cancelled";
        save();
        alert("Booking cancelled.");
        showBookings();
    }
}

function leaveReview(id) {
    let b = bookings.find(x => x.id === id && x.email === currentUser);

    if (!b || b.status !== "Confirmed" ||
        b.checkOut > new Date().toISOString().slice(0, 10)) {
        alert("You can review after your stay.");
        return;
    }

    let rating = prompt("Enter rating from 1 to 5:");
    if (!rating || !/^[1-5]$/.test(rating)) return;

    let review = prompt("Write your review:");
    if (review === null) return;

    let reviews = JSON.parse(localStorage.getItem("reviews")) || [];
    reviews.push({ bookingId: id, rating: Number(rating), review });
    localStorage.setItem("reviews", JSON.stringify(reviews));

    alert("Thank you for your review!");
}

function showAdmin() {
    showPanel("admin");
}

function adminLogin() {
    if ($("adminPassword").value !== "admin123") {
        alert("Incorrect administrator password.");
        return;
    }

    isAdmin = true;
    $("adminContent").hidden = false;
    renderAdminBookings();
    alert("Admin login successful.");
}

function updateRoom() {
    if (!isAdmin) return;

    let i = Number($("adminRoom").value);
    let qty = Number($("adminQty").value);
    let price = Number($("adminPrice").value);

    if (!Number.isInteger(qty) || qty < 0 ||
        !Number.isFinite(price) || price < 1) {
        alert("Enter a valid quantity and price.");
        return;
    }

    rooms[i].qty = qty;
    rooms[i].price = price;

    save();
    renderRooms();
    alert("Room details updated.");
}

function renderAdminBookings() {
    $("allBookings").innerHTML = bookings.map(b => `
        <div class="room">
            <p>ID: ${b.id} | ${b.email}</p>
            <p>${rooms[b.room]?.name} | ${b.checkIn} to ${b.checkOut}</p>
            <p>Status: ${b.status} | Total: ₹${b.total}</p>
            <button onclick="adminChange(${b.id})">Edit Booking</button>
            <button onclick="adminCancel(${b.id})">Cancel Booking</button>
        </div>
    `).join("") || "<p>No bookings.</p>";
}

function adminChange(id) {
    if (!isAdmin) return;

    let b = bookings.find(x => x.id === id);
    if (!b) return;

    let start = prompt("New check-in date:", b.checkIn);
    if (!start) return;

    let end = prompt("New check-out date:", b.checkOut);
    if (!end) return;

    if (end <= start || start < new Date().toISOString().slice(0, 10)) {
        alert("Invalid dates.");
        return;
    }

    if (b.status === "Confirmed" &&
        !available(b.room, start, end, b.id)) {
        alert("Room unavailable for these dates.");
        return;
    }

    b.checkIn = start;
    b.checkOut = end;
    b.total = Math.round(
        (new Date(end) - new Date(start)) / 86400000
    ) * rooms[b.room].price;

    save();
    renderAdminBookings();
    alert("Booking updated.");
}

function adminCancel(id) {
    if (!isAdmin) return;

    let b = bookings.find(x => x.id === id);
    if (!b) return;

    if (confirm("Administrator: cancel booking " + id + "?")) {
        b.status = "Cancelled";
        save();
        renderAdminBookings();
    }
}

function saveInfo() {
    if (!isAdmin) return;

    let title = $("pageTitle").value.trim();
    let content = $("pageText").value.trim();

    if (!title || !content) {
        alert("Enter a title and information.");
        return;
    }

    $("infoTitle").textContent = title;
    $("infoText").textContent = content;

    localStorage.setItem("infoTitle", title);
    localStorage.setItem("infoText", content);

    alert("Website information updated.");
}

function loadInfo() {
    let title = localStorage.getItem("infoTitle");
    let content = localStorage.getItem("infoText");

    if (title) $("infoTitle").textContent = title;
    if (content) $("infoText").textContent = content;
}

renderRooms();
loadInfo();